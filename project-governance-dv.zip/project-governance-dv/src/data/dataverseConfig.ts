export const DATAVERSE_TABLES = {
  appUsage: 'crda8_appusagelogs',
  staff: 'crda8_staff4s',
  deliverables: 'crda8_deliverableses',
  auditTrail: 'crda8_audittrail2s',
  timeOffRequests: 'crda8_timeoffrequestses',
  weeklyHours: 'crda8_weeklyhourses',
  workstreams: 'crda8_workstreamses',
} as const
